package com.sample.entity;



public class CustomerDisplayNameDTO {
    private String customerdisplayname;

    public CustomerDisplayNameDTO(String customerdisplayname) {
        this.customerdisplayname = customerdisplayname;
    }

    public String getCustomerdisplayname() {
        return customerdisplayname;
    }

    public void setCustomerdisplayname(String customerdisplayname) {
        this.customerdisplayname = customerdisplayname;
    }
}
