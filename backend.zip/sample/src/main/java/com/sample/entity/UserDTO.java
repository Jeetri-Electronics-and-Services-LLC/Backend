package com.sample.entity;



public class UserDTO {
	 private Long id;

	    private String username;

	    private String password;
	    
	    private String firstname;
	    
	    private String middlename;
	    
	    private String lastname;
	    
	    private String joiningdate;

	    private String mobilenumber;

	    private String email;

	    private String companyname;

	    private String streetname;
	    
	    private String platnumber;
	    
	    private String city;
	    
	    private String state;
	    
	    private String country;
	    
	    private String zipcode;
	    
	    private String dbaname;
	    
	    private String status;

	    private String createdby;

	    private String createddate;

	   
    private Long companyId; // Include companyId in the response for internal usage
    

    // Constructor
    public UserDTO(Long id, String username, String password, String firstname, String middlename, String lastname,
			String joiningdate, String mobilenumber, String email, String companyname, String streetname,
			String platnumber, String city, String state, String country, String zipcode, String dbaname, String status,
			String createdby, String createddate, Long companyId) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.firstname = firstname;
		this.middlename = middlename;
		this.lastname = lastname;
		this.joiningdate = joiningdate;
		this.mobilenumber = mobilenumber;
		this.email = email;
		this.companyname = companyname;
		this.streetname = streetname;
		this.platnumber = platnumber;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zipcode = zipcode;
		this.dbaname = dbaname;
		this.status = status;
		this.createdby = createdby;
		this.createddate = createddate;
		this.companyId = companyId;
	}


    // Getters and Setters...
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}


	public String getMiddlename() {
		return middlename;
	}


	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}


	public String getLastname() {
		return lastname;
	}


	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public String getJoiningdate() {
		return joiningdate;
	}


	public void setJoiningdate(String joiningdate) {
		this.joiningdate = joiningdate;
	}


	public String getMobilenumber() {
		return mobilenumber;
	}


	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getCompanyname() {
		return companyname;
	}


	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}


	public String getStreetname() {
		return streetname;
	}


	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}


	public String getPlatnumber() {
		return platnumber;
	}


	public void setPlatnumber(String platnumber) {
		this.platnumber = platnumber;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getZipcode() {
		return zipcode;
	}


	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public String getDbaname() {
		return dbaname;
	}


	public void setDbaname(String dbaname) {
		this.dbaname = dbaname;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getCreatedby() {
		return createdby;
	}


	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}


	public String getCreateddate() {
		return createddate;
	}


	public void setCreateddate(String createddate) {
		this.createddate = createddate;
	}


	public Long getCompanyId() {
		return companyId;
	}


	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

    
}

