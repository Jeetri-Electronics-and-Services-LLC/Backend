package com.sample.entity;

public class ProductRequest1 {

    private String productid;

    // Getter and Setter
    public String getProductid() {
        return productid;
    }

    public void setProductid(String productid) {
        this.productid = productid;
    }
}
