package com.sample.entity;



public class CustomerDTO {

	 private String customerdisplayname;
	 
	 // Getters and Setters

	public String getCustomerdisplayname() {
		return customerdisplayname;
	}

	public void setCustomerdisplayname(String customerdisplayname) {
		this.customerdisplayname = customerdisplayname;
	}
	 
	 
}
