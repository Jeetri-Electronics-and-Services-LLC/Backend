package com.sample.entity;

public class EstimateWithoutTaxDTOs {
	
	private Long id;
    private String descriptionwot;
    private String pricewot;
    
 // Getters and Setters
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDescriptionwot() {
		return descriptionwot;
	}
	public void setDescriptionwot(String descriptionwot) {
		this.descriptionwot = descriptionwot;
	}
	public String getPricewot() {
		return pricewot;
	}
	public void setPricewot(String pricewot) {
		this.pricewot = pricewot;
	}
    
    
    
}