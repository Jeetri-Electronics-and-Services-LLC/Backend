package com.sample.entity;



public class CustomerDetails {

    private String customerdisplayname;
    private String emailid;
    private String billingstreetaddress;
    private String billingplatnumber ;
    private String billingcity_id;
    private String billingstate_id;
    private String billingcountry_id;
    private String billingzipcode;
    private String shipingstreetaddress;
    private String shipingplatnumber ;
    private String shipingcity_id;
    private String shipingstate_id;
    private String shipingcountry_id;
    private String shipingzipcode;
   
   

    // Constructor
    
    public CustomerDetails(String customerdisplayname, String emailid, String billingstreetaddress,
			String billingplatnumber, String billingcity_id, String billingstate_id, String billingcountry_id,
			String billingzipcode, String shipingstreetaddress, String shipingplatnumber, String shipingcity_id,
			String shipingstate_id, String shipingcountry_id, String shipingzipcode) {
		
		this.customerdisplayname = customerdisplayname;
		this.emailid = emailid;
		this.billingstreetaddress = billingstreetaddress;
		this.billingplatnumber = billingplatnumber;
		this.billingcity_id = billingcity_id;
		this.billingstate_id = billingstate_id;
		this.billingcountry_id = billingcountry_id;
		this.billingzipcode = billingzipcode;
		this.shipingstreetaddress = shipingstreetaddress;
		this.shipingplatnumber = shipingplatnumber;
		this.shipingcity_id = shipingcity_id;
		this.shipingstate_id = shipingstate_id;
		this.shipingcountry_id = shipingcountry_id;
		this.shipingzipcode = shipingzipcode;
	}


    // Getters and setters

	public String getCustomerdisplayname() {
		return customerdisplayname;
	}



	public void setCustomerdisplayname(String customerdisplayname) {
		this.customerdisplayname = customerdisplayname;
	}



	public String getEmailid() {
		return emailid;
	}



	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}



	public String getBillingstreetaddress() {
		return billingstreetaddress;
	}



	public void setBillingstreetaddress(String billingstreetaddress) {
		this.billingstreetaddress = billingstreetaddress;
	}



	public String getBillingplatnumber() {
		return billingplatnumber;
	}



	public void setBillingplatnumber(String billingplatnumber) {
		this.billingplatnumber = billingplatnumber;
	}



	public String getBillingcity_id() {
		return billingcity_id;
	}



	public void setBillingcity_id(String billingcity_id) {
		this.billingcity_id = billingcity_id;
	}



	public String getBillingstate_id() {
		return billingstate_id;
	}



	public void setBillingstate_id(String billingstate_id) {
		this.billingstate_id = billingstate_id;
	}



	public String getBillingcountry_id() {
		return billingcountry_id;
	}



	public void setBillingcountry_id(String billingcountry_id) {
		this.billingcountry_id = billingcountry_id;
	}



	public String getBillingzipcode() {
		return billingzipcode;
	}



	public void setBillingzipcode(String billingzipcode) {
		this.billingzipcode = billingzipcode;
	}



	public String getShipingstreetaddress() {
		return shipingstreetaddress;
	}



	public void setShipingstreetaddress(String shipingstreetaddress) {
		this.shipingstreetaddress = shipingstreetaddress;
	}



	public String getShipingplatnumber() {
		return shipingplatnumber;
	}



	public void setShipingplatnumber(String shipingplatnumber) {
		this.shipingplatnumber = shipingplatnumber;
	}



	public String getShipingcity_id() {
		return shipingcity_id;
	}



	public void setShipingcity_id(String shipingcity_id) {
		this.shipingcity_id = shipingcity_id;
	}



	public String getShipingstate_id() {
		return shipingstate_id;
	}



	public void setShipingstate_id(String shipingstate_id) {
		this.shipingstate_id = shipingstate_id;
	}



	public String getShipingcountry_id() {
		return shipingcountry_id;
	}



	public void setShipingcountry_id(String shipingcountry_id) {
		this.shipingcountry_id = shipingcountry_id;
	}



	public String getShipingzipcode() {
		return shipingzipcode;
	}



	public void setShipingzipcode(String shipingzipcode) {
		this.shipingzipcode = shipingzipcode;
	}
    
   

	

	

	

	
   
}
