//  Display Invoice details with productdetails(Shipment Tracking)
package com.sample.entity;

public class ProductDetailDTO3 {
	
	// Getters and Setters
    private String name;
    private String qty;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQty() {
		return qty;
	}
	public void setQty(String qty) {
		this.qty = qty;
	}

    
    
}
